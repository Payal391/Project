<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Home</title>
  <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Chivo:300,700|Playfair+Display:700i" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Beth+Ellen&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Nova+Cut|Nova+Script&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/locomotive-scroll@3.5.4/dist/locomotive-scroll.css">
  <link rel="stylesheet" href="css/style_index.css">
  <link rel="stylesheet" href="css/demo.css">
  <link rel="stylesheet" href="css/products.css">

  <link rel="stylesheet" href="css/nav.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="icon" href="images/index-img/favicon.png">

</head>

<body>
  <!-- navbar -->
  <nav>
    <div class="logo">
      <h3><a href="index.php" class="logo-name"> Fashion Forever</a></h3>
    </div>

    <ul class="nav-links">
      <li><a href="index.php">Home</a></li>
      <li><a href="products.html">Products</a></li>
      <li><a href="categories.html">Categories</a></li>

      <li><a href="contact.html">ContactUs</a></li>
      <li><a href="log.php" id="login">Login</a></li>
    </ul>
    <div class="burger">
      <div class="line1"></div>
      <div class="line2"></div>
      <div class="line3"></div>
    </div>
  </nav>
  <!-- navbar -->


  <!-- ALL THE LINKS WILL GO TO products.html -->

  <a href="products.html">

    <div>
      <img class="show-on-desktop" src="101.jpg" alt="" width:100px height:100px;
      >
</div>
  </a>
  <a href="products.html">
    <div class="show-on-mobile">

    </div>
  </a>

  <br>
  <section class="section__container sale__container">
    <h2 class="main-head-of-prod">Dress to Impress<br>
      <span class="colored-word-bigger-size">Feature elegant dresses and formal attire</span>
    </h2>


    <div class="sale__grid">
      <div class="sale__card">
        <img src="images/index-img/sale-1.jpg" alt="sale" />
        <div class="sale__content">
          <p class="sale__subtitle">MAN OUTERWEAR</p>
          <h4 class="sale__title">sale <span>40%</span> off</h4>
          <p class="sale__subtitle">- DON'T MISS -</p>
          <button class="btn sale__btn"><a href="products.html"  style="color: white;">SHOP NOW</a></button>
        </div>
      </div>
      <div class="sale__card">
        <img src="images/index-img/sale-2.jpg" alt="sale" />
        <div class="sale__content">
          <p class="sale__subtitle">WOMAN T-SHIRT</p>
          <h4 class="sale__title">sale <span>10%</span> off</h4>
          <p class="sale__subtitle">- DON'T MISS -</p>
          <button class="btn sale__btn"><a href="products.html"  style="color: white;">SHOP NOW</a></button>
        </div>
      </div>
      <div class="sale__card">
        <img src="images/index-img/sale-3.jpg" alt="sale" />
        <div class="sale__content">
          <p class="sale__subtitle">JACKETS</p>
          <h4 class="sale__title">sale <span>25%</span> off</h4>
          <p class="sale__subtitle">- DON'T MISS -</p>
          <button class="btn sale__btn"><a href="products.html"  style="color: white;">SHOP NOW</a></button>
        </div>
      </div>
    </div>
  </section>

 

  <br><br>

  <h2 class="main-head-of-prod">Best selling products<br>
    <span class="colored-word-bigger-size">Promote ongoing sales or special offers</span>
  </h2>

  <div class="index-grid-img-1">
    <div>
      <a href="products.html#link2"><img src="images/index-img/anton-levin-P8prss71psk-unsplash.jpg" alt="stylish"
          srcset=""></a>
      <a href="products.html#link2">
        <h4 class="info-of-img-below">For the Young, Wild & Stylish</h4>
      </a>

    </div>
    <div>
      <a href="products.html#link2"><img src="images/index-img/bogdan-glisik-2WgOPYJuPsU-unsplash (1).jpg" alt="conquer"
          srcset=""></a>
      <a href="products.html#link2">
        <h4 class="info-of-img-below">Just like your way to Conquer</h4>
      </a>

    </div>
    <div>
      <a href="products.html#link2"><img src="images/index-img/dress.jpg" alt="stand out"></a>
      <a href="products.html#link2">
        <h4 class="info-of-img-below">Stands out like the Sun</h4>
      </a>
    </div>
  </div>
  <!-- ALL THE LINKS WILL GO TO products.html -->

  <h2 class="main-head-of-prod">TRENDING NOW<br>
    <span class="colored-word-bigger-size">From the runway to your wadrobe</span>
  </h2>



  <!-- ALL THE LINKS WILL GO TO products.html -->
  <div class="index-grid-img-2">
    
    <a href="categories.html#link2"><img class="grid" src="images/index-img/calvin-lupiya--yPg8cusGD8-unsplash.jpg" alt=""></a>
    <a href="categories.html#link2"><img class="grid" src="images/index-img/New Fashion Cloth Collection Sale Banner Design PSD - Indiater.jpg" alt=""></a>
    <a href="categories.html#link2"><img class="grid" src="images/index-img/red.jpg" alt=""></a>
    <a href="categories.html#link2"><img class="grid" src="images/index-img/images (3).jpg" alt=""></a>


  </div>
  <h2 class="main-head-of-prod">STYLES TO STEAL<br>
    <span class="colored-word-bigger-size">Inspired by influencer</span>
  </h2>



  <div class="index-grid-img-3">
    <a href="fashion.html"><img class="coll" src="images/index-img/Summer Collection.jpg" alt=""></a>
    <a href="fashion.html"><img class="coll" src="images/index-img/Hello setembro!.jpg" alt="" srcset=""></a>
    <a href="fashion.html"><img class="coll" src="images/index-img/Whoop Collection _ FW21.jpg" alt=""></a>
    <a href="fashion.html"><img class="coll" src="images/index-img/girls.jpg" alt="" srcset=""></a>
  </div>
  <!-- ALL THE LINKS WILL GO TO products.html -->

  <br><br>

  <!-- FOOTER -->
  <div class="footer-container">
    <div class="footer-1">
      <p><b>ONLINE SHOPPING</b></p>
      <h6>
        <a href="products.html#link1"> Men</a><br><br>
        <a href="products.html#link">Women </a><br><br>
        <a href="#">Kids </a><br><br>
        <a href="#"> Exclusive</a><br><br>
      </h6>
    </div>

    <div class="footer-2">
      <p><b>USEFUL LINKS</b></p>
      <h6>
        <a href="contact.html">Contact Us</a><br><br>
        <a href="#">FAQ</a><br><br>
        <a href="#">T&C</a><br><br>
        <a href="#">Blog</a><br><br>
        <a href="#">Privacy Policy</a><br><br>
      </h6>
    </div>

    <div class="footer-3">
      <p><b>100% Original</b> guarantee</p>
      <h6>
        for all products at fashionforever.com
      </h6>
      <p><b>Return within 7 days</b> of</p>
      <h6>
        receiving you order
      </h6>
      <p><b>Get free delivery</b> for every</p>
      <h6>
        order above Rs.999
      </h6>
      <br><br>
    </div>

  </div>
  <p class="copy-right"><a href="index.php">Goyal</a>&copy;2024</p>
  <br>
  <!-- FOOTER -->

  <script type="text/javascript" src="js/nav.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/locomotive-scroll@3.5.4/dist/locomotive-scroll.min.js">
</body>

</html>