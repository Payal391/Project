

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Chivo:300,700|Playfair+Display:700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Beth+Ellen|Nova+Cut&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/locomotive-scroll@3.5.4/dist/locomotive-scroll.css">

    <link rel="stylesheet" href="css/style_index.css">
    <link rel="stylesheet" href="css/demo.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="icon" href="images/index-img/favicon.png">




    
</head>
<body style="background-color: #ffffff ;">
    <!-- navbar -->
    <nav>
      <div class="logo">
        <h3><a href="index.php" class="logo-name"> Fashion Forever</a></h3>
      </div>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="products.html">Products</a></li>
        <li><a href="categories.html">Categories</a></li>

        <li><a href="contact.html">ContactUs</a></li>
        <li><a href="log.php" id="login">Login</a></li>
      </ul>
      <div class="burger">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
    </nav>
  <!-- navbar --> 
    

   <div class="wrapper">
    <div class="title-text">
      <div class="title login">Login Form</div>
      <div class="title signup">Sign Up Form</div>
    </div>
    <div class="form-container">
      <div class="slide-controls">
        <input type="radio" name="slide" id="login" checked>
        <input type="radio" name="slide" id="signup">
        <label for="login" class="slide login">Login</label>
        <label for="signup" class="slide signup">Sign Up</label>
        <div class="slider-tab"></div>
      </div>
      <div class="form-inner">
        <form class="login" action="db.php" method="post">

        <!-- <form action="#" class="login"> -->
          <div class="field">
            <input type="text" placeholder="Mobile no"  name="email_num" id="email_num" required>
          </div>
          <div class="field">
            <input type="password" placeholder="Password"  name="password" id="password"  required>
          </div>
          <!-- <div class="pass-link"><a href="#">Forgot password?</a></div> -->
          <div class="field btn">
            <div class="btn-layer"></div>
            <button type="submit" name="login">Login</button>
          </div>
          <div class="signup-link">Not a member? <a href="">Sign Up now</a></div>
        </form>
<!-- Signup -->
        <form name="register" class="signup"  action="db.php" method="post">
          <div class="field">
            <input type="text" placeholder="Full Name(Eg..Payal Goyal)" name="fullname" id="fullname" >
          </div>
          <div class="field">
            <input type="email" placeholder="Email Address(Eg..example@gmail.com)"  name="email" id="email" required>
          </div>
          <div class="field">
            <input type="tel" placeholder="Mobile no.(xxxxxxxxxx)"  name="num" id="num" pattern="[0-9]{3}[0-9]{3}[0-9]{4}"  required>
          </div>
          <div class="field">
            <input type="password" placeholder="Password(Eg..Payal@22)" name="password" id="password" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
          </div>

          <div class="field btn">
            <div class="btn-layer"></div>
            <button type="submit" name="register">Signup</button>
          </div>
        </form>
       
      </div>
    </div>
   
  </div>

  <script src="./js/log.js"></script>
  <script src="./js/nav.js"></script>
  <script src="./js/pass.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/locomotive-scroll@3.5.4/dist/locomotive-scroll.min.js">



</body>
</html>
  