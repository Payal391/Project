<!-- database connection file -->
<?php
$host = "localhost";
$username = "u718633275__goyal";
$password = "Sangeeta@22_";
$database = "u718633275__goyal";   //enter your database name 

$con = mysqli_connect($host, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
?>
