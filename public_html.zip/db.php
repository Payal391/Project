<?php
require('connection.php');

// Registration
if (isset($_POST['register'])) {
    $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $num = mysqli_real_escape_string($con, $_POST['num']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Password validation
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);
    $specialChars = preg_match('@[^\w]@', $password);

    if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
        echo "<script>alert('Password should be at least 8 characters in length and should include at least one uppercase letter, one lowercase letter, one number, and one special character.');window.location.href='log.php';</script>";
    } else {
        // Name validation
        if (!preg_match("/^[a-zA-Z\s]*$/", $fullname)) {
            echo "<script>alert('Only alphabets and whitespace are allowed for Name.');window.location.href='log.php';</script>";
            exit();
        } else if(strlen($fullname) < 2) {
            echo "<script>alert('Name should be at least 2 characters long.');window.location.href='log.php';</script>";
            exit();
        } else {
            // Email validation
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "<script>alert('Invalid email format.');window.location.href='log.php';</script>";
                exit();
            }

            // Mobile number validation
            if (!preg_match("/^\d{10}$/", $num)) {
                echo "<script>alert('Mobile number should be exactly 10 digits.');window.location.href='log.php';</script>";
                exit();
            }

            // Check if num or email already exists
            $user_exist_query = "SELECT * FROM users3 WHERE num='$num' OR email='$email'";
            $result = mysqli_query($con, $user_exist_query);

            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    $existing_user = mysqli_fetch_assoc($result);
                    if ($existing_user['num'] == $num) {
                        echo "<script>alert('Mobile number already taken');</script>";
                    } else {
                        echo "<script>alert('Email already registered');</script>";
                    }
                } else {
                    // Insert new user without hashing password (not recommended for production)
                    $insert_query = "INSERT INTO users3 (fullname, email, num, password) VALUES ('$fullname','$email', '$num', '$password')";
                    if (mysqli_query($con, $insert_query)) {
                        echo "<script>alert('Registration Successful');window.location.href='log.php';</script>";
                    } else {
                        echo "<script>alert('Cannot run query');</script>";
                    }
                }
            } else {
                echo "<script>alert('Query Error');</script>";
            }
        }
    }
}

// Login
if (isset($_POST['login'])) {
    $email_num = mysqli_real_escape_string($con, $_POST['email_num']);

    // Corrected SQL query
    $query = "SELECT * FROM users3 WHERE email = '$email_num' OR num = '$email_num'";   //user3 is table name

    $result = mysqli_query($con, $query);

    if ($result) {
        if (mysqli_num_rows($result) == 1) {
            $result_fetch = mysqli_fetch_assoc($result);
            if ($_POST['password'] === $result_fetch['password']) {
echo "
                <script>
                alert('Login Successful');
                window.location.href='index.php';
                </script>
                ";
                // Add code for successful login actions like setting session variables or redirecting
            } else {
                echo "
                <script>
                alert('Incorrect Password');
                window.location.href='log.php';
                </script>
                ";
            }
        } else {
            echo "
            <script>
            alert('Email or username Not registered');
            window.location.href='log.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
        alert('Cannot Run Query');
        window.location.href='log.php';
        </script>
        ";
    }
}

mysqli_close($con);
?>
